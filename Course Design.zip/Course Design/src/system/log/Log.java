/**
 * Author: Simon_Shi.
 * Date: Created in 21:31 2024-05-21.
 */
package system.log;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Log {
    private static final String LOG_FILE = "log/message.log";

    // 写入日志消息到文件
    public static void writeLog(String message) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(LOG_FILE, true))) {
            String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());  //打印时间戳
            writer.println("[" + timestamp + "] " + message);
        } catch (IOException e) {
            System.out.println("error in writing system.log: " + e.getMessage());
        }
    }
}
