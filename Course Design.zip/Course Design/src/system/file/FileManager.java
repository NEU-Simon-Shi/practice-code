/**
 * Author: Simon_Shi.
 * Date: Created in 21:14 2024-05-21.
 */
package system.file;

import system.data.Data;

import java.util.List;

public class FileManager implements FileManagerInterface {
    private List<Data> dataList;

    // 构造函数
    public FileManager(List<Data> dataList) {
        this.dataList = dataList;
    }

    // 在数据修改后调用此方法来重写数据文件
    public void rewrite() {
        FileManagement.writeDataToFile(dataList);
    }

    // 读取文件中的数据并更新 dataList 对象
    public void read() {
        List<Data> temp = FileManagement.readDataFromFile();
        if (temp != null) {  // 别读空的文件
            this.dataList = temp;
        }
    }

    public List<Data> getDataList() {
        return dataList;
    }

    public void setDataList(List<Data> dataList) {
        this.dataList = dataList;
    }
}
