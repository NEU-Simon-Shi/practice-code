/**
 * Author: Simon_Shi.
 * Date: Created in 21:13 2024-05-21.
 */
package system.file;

import system.data.Data;
import system.log.Log;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

// 一个静态类，专用来读写数据
public class FileManagement {
    // 写入多个数据对象到文件
    public static void writeDataToFile(List<Data> dataList) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("data/data.txt"))) {
            for (Data data : dataList) {
                writer.write(data.toString());
                writer.newLine();
            }
        } catch (IOException e) {
            Log.writeLog("Error writing system.data to system.file: " + e.getMessage());  // 日志
        }
    }

    // 读取文件中的数据并创建 Data 对象列表
    public static List<Data> readDataFromFile() {
        List<Data> dataList = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader("data/data.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] fields = line.split(",");
                Data data = new Data(
                        fields[0], fields[1], fields[2], fields[3], fields[4], fields[5], fields[6],
                        Integer.parseInt(fields[7]), Integer.parseInt(fields[8]), Integer.parseInt(fields[9]),
                        Integer.parseInt(fields[10]), Integer.parseInt(fields[11])
                );
                dataList.add(data);
            }
        } catch (IOException | NumberFormatException e) {
            Log.writeLog("Error reading system.data from system.file: " + e.getMessage());  //日志
        }
        return dataList;
    }
}
