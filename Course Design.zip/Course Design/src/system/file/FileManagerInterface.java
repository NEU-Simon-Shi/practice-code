/**
 * Author: Simon_Shi.
 * Date: Created in 21:57 2024-05-21.
 */
package system.file;

public interface FileManagerInterface {
    abstract public void rewrite();

    abstract public void read();
}
