/**
 * Author: Simon_Shi.
 * Date: Created in 23:19 2024-05-21.
 */
package system.service;

import system.data.Data;
import system.file.FileManager;
import system.log.Log;

import java.util.List;
import java.util.stream.Collectors;

public class user extends userClass {
    private final String userName;

    public user(String userName) {
        this.userName = userName;
    }

    public String getUserName() {
        return this.userName;
    }

    // query:
    public List<Data> query(String startingStation, String terminal, FileManager fileManager) { // 选项1：根据起始、终点站查询
        List<Data> dataList = fileManager.getDataList();
        Log.writeLog("user: " + userName + " query startingStation and terminal: "
                + startingStation + " and " + terminal + " successfully");
        return dataList.stream()
                .filter(data -> data.getStartingStation().equals(startingStation) && data.getTerminal().equals(terminal))
                .collect(Collectors.toList()); // filter用于过滤，collect用于收集
    }

    public Data query(String flightNumber, FileManager fileManager) { // 选项2：根据航班号查询
        List<Data> dataList = fileManager.getDataList();
        for (Data i : dataList) {
            if (i.getFlightNumber().equals(flightNumber)) {
                Log.writeLog("user: " + userName + " query by flightNumber " + flightNumber + " successfully");
                return i;
            }
        }
        Log.writeLog("user: " + userName + " query failed: flightNumber " + flightNumber + " does not exist");
        return null; // 如果没有匹配的航班，则返回null
    }

    public Data query(int option, String aircraftNumber, FileManager fileManager) { // 选项3：根据飞机号查询
        List<Data> dataList = fileManager.getDataList();
        for (Data i : dataList) {
            if (i.getFlightNumber().equals(aircraftNumber)) {
                Log.writeLog("user: " + userName + "query by aircraftNumber " + aircraftNumber + " successfully");
                return i;
            }
        }
        Log.writeLog("user: " + userName + " query failed: aircraftNumber " + aircraftNumber + " does not exist");
        return null;
    }

    public List<Data> query(boolean option, String date, FileManager fileManager) { // 选项4：根据日期查询
        List<Data> dataList = fileManager.getDataList();
        Log.writeLog("user: " + userName + " query by date " + date + " successfully");
        return dataList.stream()
                .filter(data -> data.getDate().equals(date))
                .collect(Collectors.toList());
    }

    // update:
    public Data update(String flightNumber, int choice, FileManager fileManager) { // 选项1：给航班号，买票（1、2、3等座）
        List<Data> dataList = fileManager.getDataList();
        for (Data i : dataList) {
            if (i.getFlightNumber().equals(flightNumber)) {
                switch (choice) {
                    case 1: {
                        if (i.getRemainingFirstClass() > 0) {
                            i.setRemainingFirstClass(i.getRemainingFirstClass() - 1);
                            i.setRemainingTicket(i.getRemainingTicket() - 1);
                            Log.writeLog("user: " + userName + " buy a FirstClass ticket of flightNumber: "
                                    + flightNumber + " successfully");
                            return i;
                        } else {
                            Log.writeLog("user: " + userName + " failed to buy a FirstClass ticket of flightNumber: "
                                    + flightNumber + " for no ticket");
                            return null;
                        }
                    }
                    case 2: {
                        if (i.getRemainingBusinessClass() > 0) {
                            i.setRemainingBusinessClass(i.getRemainingBusinessClass() - 1);
                            i.setRemainingTicket(i.getRemainingTicket() - 1);
                            Log.writeLog("user: " + userName + " buy a BusinessClass ticket of flightNumber: "
                                    + flightNumber + " successfully");
                            return i;
                        } else {
                            Log.writeLog("user: " + userName + " failed to buy a BusinessClass ticket of flightNumber: "
                                    + flightNumber + " for no ticket");
                            return null;
                        }
                    }
                    case 3: {
                        if (i.getRemainingEconomyClass() > 0) {
                            i.setRemainingEconomyClass(i.getRemainingEconomyClass() - 1);
                            i.setRemainingTicket(i.getRemainingTicket() - 1);
                            Log.writeLog("user: " + userName + " buy a EconomyClass ticket of flightNumber: "
                                    + flightNumber + " successfully");
                            return i;
                        } else {
                            Log.writeLog("user: " + userName + " failed to buy a EconomyClass ticket of flightNumber: "
                                    + flightNumber + " for no ticket");
                            return null;
                        }
                    }
                }
            }
        }

        Log.writeLog("user: " + userName + " query failed: flightNumber " + flightNumber + " does not exist");
        return null;
    }

    public Data update(int option, String aircraftNumber, int choice,
                       FileManager fileManager) { // 选项2：给飞机号，买票（1、2、3等座）
        List<Data> dataList = fileManager.getDataList();
        for (Data i : dataList) {
            if (i.getAircraftNumber().equals(aircraftNumber)) {
                switch (choice) {
                    case 1: {
                        if (i.getRemainingFirstClass() > 0) {
                            i.setRemainingFirstClass(i.getRemainingFirstClass() - 1);
                            i.setRemainingTicket(i.getRemainingTicket() - 1);
                            Log.writeLog("user: " + userName + " buy a FirstClass ticket of aircraftNumber: "
                                    + aircraftNumber + " successfully");
                            return i;
                        } else {
                            Log.writeLog("user: " + userName + " failed to buy a FirstClass ticket of aircraftNumber: "
                                    + aircraftNumber + " for no ticket");
                            return null;
                        }
                    }
                    case 2: {
                        if (i.getRemainingBusinessClass() > 0) {
                            i.setRemainingBusinessClass(i.getRemainingBusinessClass() - 1);
                            i.setRemainingTicket(i.getRemainingTicket() - 1);
                            Log.writeLog("user: " + userName + " buy a BusinessClass ticket of aircraftNumber: "
                                    + aircraftNumber + " successfully");
                            return i;
                        } else {
                            Log.writeLog("user: " + userName + " failed to buy a BusinessClass ticket of aircraftNumber: "
                                    + aircraftNumber + " for no ticket");
                            return null;
                        }
                    }
                    case 3: {
                        if (i.getRemainingEconomyClass() > 0) {
                            i.setRemainingEconomyClass(i.getRemainingEconomyClass() - 1);
                            i.setRemainingTicket(i.getRemainingTicket() - 1);
                            Log.writeLog("user: " + userName + " buy a EconomyClass ticket of aircraftNumber: "
                                    + aircraftNumber + " successfully");
                            return i;
                        } else {
                            Log.writeLog("user: " + userName + " failed to buy a EconomyClass ticket of aircraftNumber: "
                                    + aircraftNumber + " for no ticket");
                            return null;
                        }
                    }
                }
            }
        }

        Log.writeLog("user: " + userName + " query failed: aircraftNumber " + aircraftNumber + " does not exist");
        return null;
    }
}
