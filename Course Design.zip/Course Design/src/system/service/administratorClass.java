/**
 * Author: Simon_Shi.
 * Date: Created in 23:02 2024-05-21.
 */
package system.service;

import system.data.Data;

class administratorClass implements serviceInterface {
    public void add() {
    }

    public void delete() {
    }

    public Data query() {
        return new Data();
    }

    public void update() {
    }
}
