/**
 * Author: Simon_Shi.
 * Date: Created in 22:09 2024-05-21.
 */
package system.service;

import system.data.Data;

// 增删查改
public interface serviceInterface {
    abstract public void add();

    abstract public void delete();

    abstract public Data query();

    abstract public void update();
}
