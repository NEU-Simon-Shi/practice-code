/**
 * Author: Simon_Shi.
 * Date: Created in 23:18 2024-05-21.
 */
package system.service;

import system.data.Data;
import system.file.FileManager;
import system.log.Log;

import java.util.List;
import java.util.stream.Collectors;

public class administrator extends administratorClass {
    private final int password;

    public administrator(int password) {
        this.password = password;
    }

    public boolean checkPassword() {
        return this.password == 123456;
    }

    // add:
    public Data add(String startingStation, String terminal, String flightNumber, String aircraftNumber,
                    String departureTime, String landingTime, String date, int ratedPassengers,
                    int remainingTicket, int remainingFirstClass, int remainingBusinessClass,
                    int remainingEconomyClass, FileManager fileManager) {
        List<Data> dataList = fileManager.getDataList();
        Data temp = new Data();
        temp.setStartingStation(startingStation);
        temp.setTerminal(terminal);
        temp.setFlightNumber(flightNumber);
        temp.setAircraftNumber(aircraftNumber);
        temp.setDepartureTime(departureTime);
        temp.setLandingTime(landingTime);
        temp.setDate(date);
        temp.setRatedPassengers(ratedPassengers);
        temp.setRemainingTicket(remainingTicket);
        temp.setRemainingFirstClass(remainingFirstClass);
        temp.setRemainingBusinessClass(remainingBusinessClass);
        temp.setRemainingEconomyClass(remainingEconomyClass);
        // 以下等价，为了使用预设好的函数，使用以上方法
/**
 Data temp = new Data(startingStation, terminal, flightNumber, aircraftNumber, departureTime,
 landingTime, date, ratedPassengers, remainingTicket, remainingFirstClass,
 remainingBusinessClass, remainingEconomyClass);
 **/
        dataList.add(temp);

        fileManager.setDataList(dataList);
        Log.writeLog("administrator add successfully, flightNumber: " + flightNumber);  // 日志检查
        return temp;
    }

    // delete:
    public Data delete(String flightNumber, FileManager fileManager) {  // 选项1：根据航班号删除
        Data temp = query(flightNumber, fileManager);
        if (temp != null) { // 如果航班号存在，则进行删除操作
            List<Data> dataList = fileManager.getDataList();
            dataList.removeIf(data -> data.getFlightNumber().equals(flightNumber));
            fileManager.setDataList(dataList);
            Log.writeLog("administrator delete flightNumber " + flightNumber + " successfully");
        } // 如果航班号不存在，则记录日志并返回空数据对象
        else Log.writeLog("administrator delete failed: flightNumber " + flightNumber + " does not exist");

        return temp; // 返回被删除的航班数据（如果存在）
    }

    public Data delete(int option, String aircraftNumber, FileManager fileManager) {  // 选项2：根据飞机号删除
        Data temp = query(1, aircraftNumber, fileManager);
        if (temp != null) {
            List<Data> dataList = fileManager.getDataList();
            dataList.removeIf(data -> data.getFlightNumber().equals(aircraftNumber));
            fileManager.setDataList(dataList);
            Log.writeLog("administrator delete aircraftNumber " + aircraftNumber + " successfully");
        } else Log.writeLog("administrator delete failed: aircraftNumber " + aircraftNumber + " does not exist");

        return temp;
    }

    // query:
    public List<Data> query(String startingStation, String terminal, FileManager fileManager) { // 选项1：根据起始、终点站查询
        List<Data> dataList = fileManager.getDataList();
        Log.writeLog("administrator query startingStation and terminal: "
                + startingStation + " and " + terminal + " successfully");
        return dataList.stream()
                .filter(data -> data.getStartingStation().equals(startingStation) && data.getTerminal().equals(terminal))
                .collect(Collectors.toList()); // filter用于过滤，collect用于收集
    }

    public Data query(String flightNumber, FileManager fileManager) { // 选项2：根据航班号查询
        List<Data> dataList = fileManager.getDataList();
        for (Data i : dataList) {
            if (i.getFlightNumber().equals(flightNumber)) {
                Log.writeLog("administrator query by flightNumber " + flightNumber + " successfully");
                return i;
            }
        }
        Log.writeLog("administrator query failed: flightNumber " + flightNumber + " does not exist");
        return null; // 如果没有匹配的航班，则返回null
    }

    public Data query(int option, String aircraftNumber, FileManager fileManager) { // 选项3：根据飞机号查询
        List<Data> dataList = fileManager.getDataList();
        for (Data i : dataList) {
            if (i.getFlightNumber().equals(aircraftNumber)) {
                Log.writeLog("administrator query by aircraftNumber " + aircraftNumber + " successfully");
                return i;
            }
        }
        Log.writeLog("administrator query failed: aircraftNumber " + aircraftNumber + " does not exist");
        return null;
    }

    public List<Data> query(boolean option, String date, FileManager fileManager) { // 选项4：根据日期查询
        List<Data> dataList = fileManager.getDataList();
        Log.writeLog("administrator query by date " + date + " successfully");
        return dataList.stream()
                .filter(data -> data.getDate().equals(date))
                .collect(Collectors.toList());
    }

    // update:
    public Data update(String flightNumber, String departureTime, String landingTime, String date,
                       FileManager fileManager) {  // 选项1：给航班号，改起飞时间、落地时间、飞行日期
        List<Data> dataList = fileManager.getDataList();
        Data temp;

        for (Data i : dataList) {
            if (i.getFlightNumber().equals(flightNumber)) {
                i.setDepartureTime(departureTime);
                i.setLandingTime(landingTime);
                i.setDate(date);

                temp = i;
                fileManager.setDataList(dataList);
                Log.writeLog("administrator update " + flightNumber + " successfully");
                return temp;
            }
        }
        Log.writeLog("administrator update failed: flightNumber " + flightNumber + " does not exist");
        return null;
    }

    public Data update(int option, String aircraftNumber, String departureTime, String landingTime, String date,
                       FileManager fileManager) {  // 选项2：给飞机号，改起飞时间、落地时间、飞行日期
        List<Data> dataList = fileManager.getDataList();
        Data temp;

        for (Data i : dataList) {
            if (i.getFlightNumber().equals(aircraftNumber)) {
                i.setDepartureTime(departureTime);
                i.setLandingTime(landingTime);
                i.setDate(date);

                temp = i;
                fileManager.setDataList(dataList);
                Log.writeLog("administrator update " + aircraftNumber + " successfully");
                return temp;
            }
        }
        Log.writeLog("administrator update failed: aircraftNumber " + aircraftNumber + " does not exist");
        return null;
    }

    public Data update(String flightNumber, String startingStation, String terminal,
                       FileManager fileManager) {  // 选项3：给航班号，改起点站、终点站
        List<Data> dataList = fileManager.getDataList();
        Data temp;

        for (Data i : dataList) {
            if (i.getFlightNumber().equals(flightNumber)) {
                i.setStartingStation(startingStation);
                i.setTerminal(terminal);

                temp = i;
                fileManager.setDataList(dataList);
                Log.writeLog("administrator update " + flightNumber + " successfully");
                return temp;
            }
        }
        Log.writeLog("administrator update failed: flightNumber " + flightNumber + " does not exist");
        return null;
    }

    public Data update(int option, String aircraftNumber, String startingStation, String terminal,
                       FileManager fileManager) {  // 选项4：给飞机号，改起点站、终点站
        List<Data> dataList = fileManager.getDataList();
        Data temp;

        for (Data i : dataList) {
            if (i.getFlightNumber().equals(aircraftNumber)) {
                i.setStartingStation(startingStation);
                i.setTerminal(terminal);

                temp = i;
                fileManager.setDataList(dataList);
                Log.writeLog("administrator update " + aircraftNumber + " successfully");
                return temp;
            }
        }
        Log.writeLog("administrator update failed: aircraftNumber " + aircraftNumber + " does not exist");
        return null;
    }
}
