/**
 * Author: Simon_Shi.
 * Date: Created in 23:02 2024-05-21.
 */
package system.service;

import system.data.Data;

class userClass implements serviceInterface {
    public void add() {
    }  // no use

    public void delete() {
    }  // no use

    public Data query() {
        return new Data();
    }

    public void update() {
    }
}
