/**
 * Author: Simon_Shi.
 * Date: Created in 21:08 2024-05-21.
 */
package system.data;

public class Data {
    private String startingStation;  // 起点站
    private String terminal;  // 终点站
    private String flightNumber;  // 航班号
    private String aircraftNumber;  // 飞机号，固定不变
    private String departureTime;  // 起飞时间
    private String landingTime;  // 落地时间
    private String date;  // 飞行日期 eg: 07.12 或 11.02 或 01.01


    private int ratedPassengers;  // 乘员定额
    private int remainingTicket;  // 总余票量
    private int remainingFirstClass;  // 头等舱余票量
    private int remainingBusinessClass;  // 商务舱余票量
    private int remainingEconomyClass;  // 经济舱余票量


    // 构造函数
    public Data() {
    }

    public Data(String startingStation, String terminal, String flightNumber, String aircraftNumber,
                String departureTime, String landingTime, String date, int ratedPassengers,
                int remainingTicket, int remainingFirstClass, int remainingBusinessClass,
                int remainingEconomyClass) {
        this.startingStation = startingStation;
        this.terminal = terminal;
        this.flightNumber = flightNumber;
        this.aircraftNumber = aircraftNumber;
        this.departureTime = departureTime;
        this.landingTime = landingTime;
        this.date = date;
        this.ratedPassengers = ratedPassengers;
        this.remainingTicket = remainingTicket;
        this.remainingFirstClass = remainingFirstClass;
        this.remainingBusinessClass = remainingBusinessClass;
        this.remainingEconomyClass = remainingEconomyClass;
    }

    // Get, Set方法
    public String getStartingStation() {
        return startingStation;
    }

    public void setStartingStation(String startingStation) {
        this.startingStation = startingStation;
    }

    public String getTerminal() {
        return terminal;
    }

    public void setTerminal(String terminal) {
        this.terminal = terminal;
    }

    public String getFlightNumber() {
        return flightNumber;
    }

    public void setFlightNumber(String flightNumber) {
        this.flightNumber = flightNumber;
    }

    public String getAircraftNumber() {
        return aircraftNumber;
    }

    public void setAircraftNumber(String aircraftNumber) {
        this.aircraftNumber = aircraftNumber;
    }

    public String getDepartureTime() {
        return departureTime;
    }

    public void setDepartureTime(String departureTime) {
        this.departureTime = departureTime;
    }

    public String getLandingTime() {
        return landingTime;
    }

    public void setLandingTime(String landingTime) {
        this.landingTime = landingTime;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public int getRatedPassengers() {
        return ratedPassengers;
    }

    public void setRatedPassengers(int ratedPassengers) {
        this.ratedPassengers = ratedPassengers;
    }

    public int getRemainingTicket() {
        return remainingTicket;
    }

    public void setRemainingTicket(int remainingTicket) {
        this.remainingTicket = remainingTicket;
    }

    public int getRemainingFirstClass() {
        return remainingFirstClass;
    }

    public void setRemainingFirstClass(int remainingFirstClass) {
        this.remainingFirstClass = remainingFirstClass;
    }

    public int getRemainingBusinessClass() {
        return remainingBusinessClass;
    }

    public void setRemainingBusinessClass(int remainingBusinessClass) {
        this.remainingBusinessClass = remainingBusinessClass;
    }

    public int getRemainingEconomyClass() {
        return remainingEconomyClass;
    }

    public void setRemainingEconomyClass(int remainingEconomyClass) {
        this.remainingEconomyClass = remainingEconomyClass;
    }

    // Method to represent the system.data as a string (for saving to system.file)  转换成string用于写入（十进制版）
    @Override
    public String toString() {
        return startingStation + "," + terminal + "," + flightNumber + "," + aircraftNumber + "," +
                departureTime + "," + landingTime + "," + date + "," + ratedPassengers + "," +
                remainingTicket + "," + remainingFirstClass + "," + remainingBusinessClass + "," +
                remainingEconomyClass;
    }
}
