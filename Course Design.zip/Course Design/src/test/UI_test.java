/**
 * Author: Simon_Shi.
 * Date: Created in 13:55 2024-05-22.
 */
package test;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class UI_test {
    public static void main(String[] args) {
        // 创建框架
        JFrame frame = new JFrame("Input Processor");
        frame.setSize(400, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);

        // 创建输入标签
        JLabel inputLabel = new JLabel("Enter text:");
        inputLabel.setBounds(50, 50, 100, 30);
        frame.add(inputLabel);

        // 创建输入文本框
        JTextField inputField = new JTextField();
        inputField.setBounds(150, 50, 200, 30);
        frame.add(inputField);

        // 创建按钮
        JButton processButton = new JButton("Process");
        processButton.setBounds(150, 100, 100, 30);
        frame.add(processButton);

        // 创建输出标签
        JLabel outputLabel = new JLabel("Result:");
        outputLabel.setBounds(50, 150, 300, 30);
        frame.add(outputLabel);

        // 创建后端处理类的实例
        DataProcessor processor = new DataProcessor();

        // 为按钮添加事件监听器
        processButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // 获取用户输入
                String input = inputField.getText();

                // 调用后端函数处理输入
                String result = processor.processInput(input);

                // 显示处理结果
                outputLabel.setText("Result: " + result);
            }
        });

        // 显示框架
        frame.setVisible(true);
    }
}

class DataProcessor {
    public String processInput(String input) {
        // 假设处理逻辑是将输入转换为大写
        return input.toUpperCase() + "一切正常";
    }
}
