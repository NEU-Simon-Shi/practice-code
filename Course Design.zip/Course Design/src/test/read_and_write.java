/**
 * Author: Simon_Shi.
 * Date: Created in 21:16 2024-05-21.
 */
package test;

import system.data.Data;
import system.file.FileManager;
import system.service.administrator;
import system.service.user;

import java.util.ArrayList;
import java.util.List;

public class read_and_write {
    public static void main(String[] args) {
        // 创建多个 Data 对象
        List<Data> dataList = new ArrayList<>();
        dataList.add(new Data("Beijing", "Shanghai", "CA1234", "Boeing 737", "08:00", "10:30", "7.12",
                200, 150, 10, 20, 120));
        dataList.add(new Data("New York", "Los Angeles", "AA5678", "Airbus A320", "09:00", "12:30", "7.13",
                180, 160, 5, 15, 140));
        // 可以添加更多的 Data 对象

        // 创建 FileManager 对象
        FileManager fileManager = new FileManager(dataList);

        // 写入数据到文件
        fileManager.rewrite();

        // 从文件读取数据
        fileManager.read();

        // 显示读取的数据
        for (Data data : fileManager.getDataList()) {
            System.out.println(data.toString());
        }
    }
}

//// 使用示例：
//    List<Data> dataList = new ArrayList<>();
//    // 创建 FileManager 对象
//    FileManager fileManager = new FileManager(dataList);
//    // 从文件读取数据
//    fileManager.read();
